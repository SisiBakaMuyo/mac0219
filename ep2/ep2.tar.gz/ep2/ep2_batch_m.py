from time import sleep
from tqdm import tqdm
import subprocess
regiaoA = {
  "0": "-0.188 -0.012 0.554 0.754"
}
processos = [1, 2, 3, 4, 6, 12, 16]
threads = [1, 2, 3, 4, 6, 12, 16]
with tqdm(total=735) as pbar:
    for p in processos:
      for thread in threads:
          for execu in range(15):
              PTH = "mpirun --bind-to none --host localhost:" + str(p) + " -np " + str(p) + " ./mandelbrot_mpi_pth " + " " + regiaoA[str(0)] + " 4096 " + str(thread) + ' "' + ";m_PTH;" + str(0) + ";4096;" + str(p) + ";" + str(thread) + ";" + str(execu) + '"' + " >> ./ep2_log_m_pth.csv"
              OMP = "mpirun --bind-to none --host localhost:" + str(p) + " -np " + str(p) + " ./mandelbrot_mpi_omp " + " " + regiaoA[str(0)] + " 4096 " + str(thread) + ' "' + ";m_OMP;" + str(0) + ";4096;" + str(p) + ";" + str(thread) + ";" + str(execu) + '"' + " >> ./ep2_log_m_omp.csv"
              subprocess.check_call(OMP, shell=True)                  
              subprocess.check_call(PTH, shell=True)        
              pbar.update()
                    