from time import sleep
from tqdm import tqdm
import subprocess
regiaoA = {
  "0": "-0.188 -0.012 0.554 0.754"
}
with tqdm(total=15) as pbar:
                for execu in range(15):
                    thread = 0
                    SEQ = "./mandelbrot_seq " + " " + regiaoA[str(0)] + " 4096 " + str(2**(thread)) + ' "' + ";SEQ;" + str(0) + ";4096;" + str(2**(thread)) + ";" + str(execu) + '"' + " >> ./ep2_log_seq.csv"
                    subprocess.check_call(SEQ, shell=True)                    
                    pbar.update()

processos = [1, 2, 3, 4, 6, 12, 16]
with tqdm(total=105) as pbar:
  for p in processos:
    for execu in range(15):
        thread = 0
        SEQ = "mpirun --bind-to none --host localhost:" + str(p) + " -np " + str(p) + " ./mandelbrot_mpi_seq " + " " + regiaoA[str(0)] + " 4096 " + str(2**(thread)) + ' "' + ";m_SEQ;" + str(0) + ";4096;" + str(p) + ";" + str(2**(thread)) + ";" + str(execu) + '"' + " >> ./ep2_log_m_seq.csv"
        subprocess.check_call(SEQ, shell=True)                    
        pbar.update()

              