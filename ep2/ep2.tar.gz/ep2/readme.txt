Notebook: DriveMAC0219_EP2_12.ipynb

PDF do Notebook: DriveMAC0219_EP2_12.pdf

Scripts python que geram os csvs:
 ep2_batch_m.py
 ep2_batch_s.py
 ep2_batch_t.py

Arquivos csvs:
 ep2_log_m_omp.csv
 ep2_log_m_pth.csv
 ep2_log_m_seq.csv
 ep2_log_seq.csv
 ep2_log_t_omp.csv
 ep2_log_t_pth.csv

Programas/fontes C e executaveis:
 Makefile
 mandelbrot_mpi_omp
 mandelbrot_mpi_omp.c
 mandelbrot_mpi_pth
 mandelbrot_mpi_pth.c
 mandelbrot_mpi_seq
 mandelbrot_mpi_seq.c
 mandelbrot_omp
 mandelbrot_omp.c
 mandelbrot_pth
 mandelbrot_pth.c
 mandelbrot_seq
 mandelbrot_seq.c
