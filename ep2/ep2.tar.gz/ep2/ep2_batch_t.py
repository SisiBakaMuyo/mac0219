from time import sleep
from tqdm import tqdm
import subprocess
regiaoA = {
  "0": "-0.188 -0.012 0.554 0.754"
}
threads = [1, 2, 3, 4, 6, 12, 16]
with tqdm(total=105) as pbar:
    for thread in threads:
        for execu in range(15):
            PTH = "./mandelbrot_pth " + " " + regiaoA[str(0)] + " 4096 " + str(thread) + ' "' + ";PTH;" + str(0) + ";4096;" + str(thread) + ";" + str(execu) + '"' + " >> ./ep2_log_t_pth.csv"
            OMP = "./mandelbrot_omp " + " " + regiaoA[str(0)] + " 4096 " + str(thread) + ' "' + ";OMP;" + str(0) + ";4096;" + str(thread) + ";" + str(execu) + '"' + " >> ./ep2_log_t_omp.csv"
            subprocess.check_call(OMP, shell=True)                  
            subprocess.check_call(PTH, shell=True)        
            pbar.update()
                    